Observe
↓
Inquire
↓
Assess
↓
Understand
↓
Steward
↓
Cultivate
↓
Change
↓
Repeat to Sustain Organizational Health
