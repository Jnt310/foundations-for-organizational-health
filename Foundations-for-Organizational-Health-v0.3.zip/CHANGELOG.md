# CHANGELOG

## v0.3
- Ratified FP-005.
- Added Foundations Cycle.
- Added Incubator.
- Added first incubating idea.
