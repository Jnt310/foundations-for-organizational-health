# First Principles

FP-001: Organizations are evolving ecosystems whose health is shaped by the interconnection among their people, systems, structures, and shared purpose.

FP-002: Every organization is capable of change.

FP-003: The direction of organizational change is shaped by the conditions within the ecosystem.

FP-004: Every component of an organization contributes to the conditions of its ecosystem.

FP-005: Every organizational ecosystem contains strengths that can be leveraged to strengthen areas of need.
