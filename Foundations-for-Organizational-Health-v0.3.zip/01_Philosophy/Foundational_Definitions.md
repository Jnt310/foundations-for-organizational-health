Organizational Health: An organization's capacity to sustainably fulfill its mission.

Organizational Success: The fulfillment of the mission an organization has chosen.

Health describes capacity. Success describes mission fulfillment.
