Purpose -> Philosophy -> First Principles -> Foundational Definitions -> Foundational Concepts -> Foundations Cycle -> Framework -> Diagnostic -> Interventions -> Outcomes
