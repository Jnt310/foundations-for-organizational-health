# The Incubator

A permanent home for ideas before they are ready for the formal philosophy.
